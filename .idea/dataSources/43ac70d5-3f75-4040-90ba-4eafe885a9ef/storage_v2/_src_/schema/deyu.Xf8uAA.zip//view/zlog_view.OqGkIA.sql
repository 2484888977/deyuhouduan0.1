create definer = root@localhost view zlog_view as
select `deyu`.`stu_view`.`s_name`            AS `s_name`,
       `deyu`.`stu_view`.`s_sex`             AS `s_sex`,
       `deyu`.`stu_view`.`s_class`           AS `s_class`,
       `deyu`.`stu_view`.`majorinfo`         AS `majorinfo`,
       `deyu`.`stu_view`.`collegeinfo`       AS `collegeinfo`,
       `deyu`.`stu_view`.`teacherinfo`       AS `teacherinfo`,
       `deyu`.`user_view`.`username`         AS `username`,
       `deyu`.`user_view`.`u_name`           AS `u_name`,
       `deyu`.`user_view`.`u_sex`            AS `u_sex`,
       `deyu`.`user_view`.`jurisdiction`     AS `jurisdiction`,
       `deyu`.`user_view`.`u_class`          AS `u_class`,
       `deyu`.`user_view`.`jurisdictioninfo` AS `jurisdictioninfo`,
       `deyu`.`user_view`.`collegeinfo`      AS `collegeinfo_0`,
       `deyu`.`user_view`.`userinfo`         AS `userinfo`,
       `deyu`.`scorefirst`.`scoreinfo`       AS `scoreinfo`,
       `deyu`.`scoresec`.`scoresecinfo`      AS `scoresecinfo`,
       `deyu`.`operation`.`operationinfo`    AS `operationinfo`,
       `deyu`.`scoreclass`.`classinfo`       AS `classinfo`,
       `deyu`.`scoreoperation`.`score`       AS `score`,
       `deyu`.`scoreoperation`.`id`          AS `id`,
       `deyu`.`stu_view`.`s_id`              AS `s_id`,
       `deyu`.`stu_view`.`s_proid`           AS `s_proid`,
       `deyu`.`scoreoperation`.`datetime`    AS `datetime`,
       `deyu`.`scoreoperation`.`ip`          AS `ip`,
       `deyu`.`scoreoperation`.`info`        AS `info`,
       `deyu`.`scoreoperation`.`othertime`   AS `othertime`,
       `deyu`.`scoreoperation`.`othername`   AS `othername`,
       `deyu`.`scoreoperation`.`otherstate`  AS `otherstate`,
       `deyu`.`test`.`testinfo`              AS `testinfo`,
       `deyu`.`user_view`.`u_classinfo`      AS `u_classinfo`,
       `deyu`.`stu_view`.`collegeid`         AS `collegeid`,
       `deyu`.`scoreoperation`.`opstate`     AS `opstate`
from (((((((`deyu`.`stu_view` join `deyu`.`user_view`) join `deyu`.`scoreoperation`) join `deyu`.`scorefirst`) join `deyu`.`scoresec`) join `deyu`.`operation`) join `deyu`.`scoreclass`)
         join `deyu`.`test`)
where ((`deyu`.`scoreoperation`.`stuid` = `deyu`.`stu_view`.`s_id`) and
       (`deyu`.`scoreoperation`.`opusername` = `deyu`.`user_view`.`username`) and
       (`deyu`.`scoreoperation`.`opscoreclass` = `deyu`.`scoreclass`.`classid`) and
       (`deyu`.`scoreoperation`.`opstate` = `deyu`.`operation`.`operationid`) and
       (`deyu`.`scoreoperation`.`opscorefir` = `deyu`.`scorefirst`.`scoreid`) and
       (`deyu`.`scoreoperation`.`opscoresec` = `deyu`.`scoresec`.`scoresecid`) and
       (`deyu`.`scoreoperation`.`otherstate` = `deyu`.`test`.`testid`));

