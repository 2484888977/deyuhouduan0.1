create definer = root@localhost view score_view as
select `deyu`.`scoreoperation`.`id`             AS `id`,
       `deyu`.`scoreoperation`.`stuid`          AS `stuid`,
       `deyu`.`scoreoperation`.`stuname`        AS `stuname`,
       `deyu`.`scoreoperation`.`stusex`         AS `stusex`,
       `deyu`.`scoreoperation`.`stuclass`       AS `stuclass`,
       `deyu`.`scoreoperation`.`opcollege`      AS `opcollegeid`,
       `deyu`.`college`.`collegeinfo`           AS `collegeinfo`,
       `deyu`.`scoreoperation`.`opmajor`        AS `opmajorid`,
       `deyu`.`major`.`majorinfo`               AS `majorinfo`,
       `deyu`.`scoreoperation`.`opteacher`      AS `opteacherid`,
       `deyu`.`teacher`.`teacherinfo`           AS `teacherinfo`,
       `deyu`.`scoreoperation`.`opusername`     AS `opusername`,
       `deyu`.`scoreoperation`.`opname`         AS `opname`,
       `deyu`.`scoreoperation`.`opjurisdiction` AS `opjurisdictionid`,
       `deyu`.`qxinfo`.`jurisdictioninfo`       AS `jurisdictioninfo`,
       `deyu`.`scoreoperation`.`opclass`        AS `opclassid`,
       `deyu`.`userclass`.`userinfo`            AS `opclassinfo`,
       `deyu`.`scoreoperation`.`opclassinfo`    AS `useropcollegeid`,
       `deyu`.`collegetwo`.`collegeinfo`        AS `usercollegeinfo`,
       `deyu`.`scoreoperation`.`opscoreclass`   AS `opscoreclassid`,
       `deyu`.`scoreclass`.`classinfo`          AS `scoreclassinfo`,
       `deyu`.`scoreoperation`.`score`          AS `score`,
       `deyu`.`scoreoperation`.`opstate`        AS `opstate`,
       `deyu`.`operation`.`operationinfo`       AS `operationinfo`,
       `deyu`.`scoreoperation`.`opscorefir`     AS `opscorefir`,
       `deyu`.`scorefirst`.`scoreinfo`          AS `scoreinfo`,
       `deyu`.`scoreoperation`.`opscoresec`     AS `opscoresec`,
       `deyu`.`scoresec`.`scoresecinfo`         AS `scoresecinfo`,
       `deyu`.`scoreoperation`.`ip`             AS `ip`,
       `deyu`.`scoreoperation`.`datetime`       AS `datetime`,
       `deyu`.`scoreoperation`.`shibie`         AS `shibie`
from ((((((((((`deyu`.`scoreoperation` join `deyu`.`college`) join `deyu`.`operation`) join `deyu`.`scoreclass`) join `deyu`.`scorefirst`) join `deyu`.`scoresec`) join `deyu`.`major`) join `deyu`.`teacher`) join `deyu`.`qxinfo`) join `deyu`.`userclass`)
         join `deyu`.`collegetwo`)
where ((`deyu`.`scoreoperation`.`opcollege` = `deyu`.`college`.`collegeid`) and
       (`deyu`.`scoreoperation`.`opclassinfo` = `deyu`.`collegetwo`.`collegeid`) and
       (`deyu`.`scoreoperation`.`opmajor` = `deyu`.`major`.`majorid`) and
       (`deyu`.`scoreoperation`.`opteacher` = `deyu`.`teacher`.`teacherid`) and
       (`deyu`.`scoreoperation`.`opjurisdiction` = `deyu`.`qxinfo`.`jurisdiction`) and
       (`deyu`.`scoreoperation`.`opclass` = `deyu`.`userclass`.`userid`) and
       (`deyu`.`scoreoperation`.`opscoreclass` = `deyu`.`scoreclass`.`classid`) and
       (`deyu`.`scoreoperation`.`opstate` = `deyu`.`operation`.`operationid`) and
       (`deyu`.`scoreoperation`.`opscorefir` = `deyu`.`scorefirst`.`scoreid`) and
       (`deyu`.`scoreoperation`.`opscoresec` = `deyu`.`scoresec`.`scoresecid`));

