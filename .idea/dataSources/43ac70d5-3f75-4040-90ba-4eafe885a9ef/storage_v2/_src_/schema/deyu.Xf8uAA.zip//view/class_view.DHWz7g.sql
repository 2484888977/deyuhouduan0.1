create definer = root@localhost view class_view as
select `deyu`.`classes`.`classes`     AS `classes`,
       `deyu`.`classes`.`teacherid`   AS `teacherid`,
       `deyu`.`classes`.`majorid`     AS `majorid`,
       `deyu`.`classes`.`collegeid`   AS `collegeid`,
       `deyu`.`college`.`collegeinfo` AS `collegeinfo`,
       `deyu`.`teacher`.`teacherinfo` AS `teacherinfo`,
       `deyu`.`major`.`majorinfo`     AS `majorinfo`
from (((`deyu`.`classes` join `deyu`.`college`) join `deyu`.`teacher`)
         join `deyu`.`major`)
where ((`deyu`.`classes`.`majorid` = `deyu`.`major`.`majorid`) and
       (`deyu`.`major`.`collegeid` = `deyu`.`college`.`collegeid`) and
       (`deyu`.`classes`.`teacherid` = `deyu`.`teacher`.`teacherid`));

