create definer = root@localhost view apartment_view as
select `deyu`.`college`.`collegeinfo`     AS `collegeinfo`,
       `deyu`.`apartment`.`apartmentid`   AS `apartmentid`,
       `deyu`.`apartment`.`apartmentinfo` AS `apartmentinfo`,
       `deyu`.`apartment`.`collegeid`     AS `collegeid`
from (`deyu`.`college`
         join `deyu`.`apartment`)
where (`deyu`.`college`.`collegeid` = `deyu`.`apartment`.`collegeid`);

