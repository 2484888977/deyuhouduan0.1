create definer = root@localhost view user_tea_view as
select `deyu`.`user_view`.`username`         AS `username`,
       `deyu`.`user_view`.`u_id`             AS `u_id`,
       `deyu`.`user_view`.`password`         AS `password`,
       `deyu`.`user_view`.`u_mail`           AS `u_mail`,
       `deyu`.`user_view`.`u_name`           AS `u_name`,
       `deyu`.`user_view`.`u_sex`            AS `u_sex`,
       `deyu`.`user_view`.`u_add`            AS `u_add`,
       `deyu`.`user_view`.`jurisdiction`     AS `jurisdiction`,
       `deyu`.`user_view`.`u_class`          AS `u_class`,
       `deyu`.`user_view`.`stateCode`        AS `stateCode`,
       `deyu`.`user_view`.`info`             AS `info`,
       `deyu`.`user_view`.`user_id`          AS `user_id`,
       `deyu`.`user_view`.`address`          AS `address`,
       `deyu`.`user_view`.`qq`               AS `qq`,
       `deyu`.`user_view`.`vx`               AS `vx`,
       `deyu`.`user_view`.`userinfo`         AS `userinfo`,
       `deyu`.`user_view`.`jurisdictioninfo` AS `jurisdictioninfo`,
       `deyu`.`user_view`.`stateinfo`        AS `stateinfo`,
       `deyu`.`user_view`.`collegeinfo`      AS `collegeinfo`,
       `deyu`.`user_view`.`u_classinfo`      AS `u_classinfo`,
       `deyu`.`user_view`.`openid`           AS `openid`,
       `deyu`.`teacher`.`teacheradd`         AS `teacheradd`,
       `deyu`.`teacher`.`teachersex`         AS `teachersex`,
       `deyu`.`teacher`.`teacherinfo`        AS `teacherinfo`,
       `deyu`.`teacher`.`collegeid`          AS `collegeid`,
       `deyu`.`teacher`.`teacherid`          AS `teacherid`
from (`deyu`.`user_view`
         join `deyu`.`teacher`)
where (`deyu`.`user_view`.`u_add` = `deyu`.`teacher`.`teacheradd`);

