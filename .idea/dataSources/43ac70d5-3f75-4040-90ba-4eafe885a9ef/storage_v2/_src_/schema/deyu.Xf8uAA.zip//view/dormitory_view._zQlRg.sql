create definer = root@localhost view dormitory_view as
select `deyu`.`apartment`.`apartmentinfo` AS `apartmentinfo`,
       `deyu`.`dormitory`.`dormitoryid`   AS `dormitoryid`,
       `deyu`.`dormitory`.`apartmentid`   AS `apartmentid`,
       `deyu`.`dormitory`.`dormitoryinfo` AS `dormitoryinfo`
from (`deyu`.`apartment`
         join `deyu`.`dormitory`)
where (`deyu`.`apartment`.`apartmentid` = `deyu`.`dormitory`.`apartmentid`);

